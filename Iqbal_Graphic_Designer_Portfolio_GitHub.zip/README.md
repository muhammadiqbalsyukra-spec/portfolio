# Iqbal Graphic Designer Portfolio
Website portfolio single-file, responsive, untuk GitHub Pages.

## Upload
1. Buat repository baru, misalnya `graphic-designer-portfolio`.
2. Upload `index.html` dan `Portfolio_Graphic_Designer_Iqbal.pdf`.
3. Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.
4. Setelah aktif, buka URL GitHub Pages yang diberikan GitHub.

## Wajib diedit
Cari `your-email@example.com` di `index.html`, lalu ganti dengan email aktif.
